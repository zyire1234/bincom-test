"""Build bincom.sqlite3 from bincom_test.sql (for local use / free hosting without MySQL).
Usage: python setup_sqlite.py path/to/bincom_test.sql
"""
import re, sqlite3, sys, os
src = sys.argv[1] if len(sys.argv) > 1 else "bincom_test.sql"
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bincom.sqlite3")
if os.path.exists(out): os.remove(out)
s = open(src, encoding="latin1").read()
db = sqlite3.connect(out)
INT = {"uniqueid","lga_id","ward_id","uniquewardid","state_id","polling_unit_id","party_score","result_id","id","name_id","pollingunit_uniqueid"}
PK = {"announced_pu_results":"result_id","announced_lga_results":"result_id","announced_state_results":"result_id",
      "announced_ward_results":"result_id","lga":"uniqueid","ward":"uniqueid","polling_unit":"uniqueid","party":"id",
      "agentname":"name_id","states":"state_id"}
for m in re.finditer(r"CREATE TABLE IF NOT EXISTS `(\w+)` \((.*?)\) ENGINE", s, re.S):
    t = m.group(1)
    cols = re.findall(r"^\s*`(\w+)`", m.group(2), re.M)
    defs = []
    for c in cols:
        if c == PK[t]:
            defs.append(f'"{c}" INTEGER PRIMARY KEY AUTOINCREMENT' if t != "states" else f'"{c}" INTEGER PRIMARY KEY')
        else:
            defs.append(f'"{c}" {"INTEGER" if c in INT else "TEXT"}')
    db.execute(f'CREATE TABLE "{t}" ({",".join(defs)})')
for m in re.finditer(r"INSERT INTO `(\w+)` \(([^)]*)\) VALUES\n(.*?);\n", s, re.S):
    cols = ",".join('"%s"' % c.strip("` ") for c in m.group(2).split(","))
    db.executescript(f'INSERT INTO "{m.group(1)}" ({cols}) VALUES\n{m.group(3).replace(chr(92)+chr(39), chr(39)*2)};')
db.commit()
print("Built", out)

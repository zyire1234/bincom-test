from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("polling-unit/", views.polling_unit_result, name="q1"),
    path("lga-total/", views.lga_total, name="q2"),
    path("new-result/", views.new_result, name="q3"),
    path("api/wards/", views.api_wards, name="api_wards"),
    path("api/polling-units/", views.api_polling_units, name="api_pus"),
]

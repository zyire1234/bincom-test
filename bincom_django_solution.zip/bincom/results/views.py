from django.db import transaction
from django.db.models import Sum
from django.http import JsonResponse
from django.shortcuts import render
from django.utils import timezone

from .models import AnnouncedPuResult, Lga, Party, PollingUnit, Ward


def _lgas():
    # Delta State = 25. Natural sort by name.
    return Lga.objects.filter(state_id=25).order_by("lga_name")


def _party_codes():
    # announced_pu_results.party_abbreviation is CHAR(4), so LABOUR is stored as LABO.
    return [(p.partyid, p.partyid[:4]) for p in Party.objects.order_by("id")]


def home(request):
    return render(request, "results/home.html")


# ---- JSON endpoints for the chained dropdowns --------------------------------
def api_wards(request):
    lga_id = request.GET.get("lga_id")
    qs = Ward.objects.filter(lga_id=lga_id).order_by("ward_name") if lga_id else Ward.objects.none()
    return JsonResponse([{"id": w.uniqueid, "name": w.ward_name} for w in qs], safe=False)


def api_polling_units(request):
    ward = request.GET.get("ward_id")  # ward.uniqueid
    qs = PollingUnit.objects.filter(uniquewardid=ward).order_by("polling_unit_name") if ward else PollingUnit.objects.none()
    ids = set(AnnouncedPuResult.objects.filter(
        polling_unit_uniqueid__in=[str(p.uniqueid) for p in qs]
    ).values_list("polling_unit_uniqueid", flat=True))
    return JsonResponse([
        {"id": p.uniqueid,
         "name": f"{p.polling_unit_name or 'Unnamed'} ({p.polling_unit_number or 'no number'})",
         "has_results": str(p.uniqueid) in ids}
        for p in qs], safe=False)


# ---- Question 1 ----------------------------------------------------------------
def polling_unit_result(request):
    ctx = {"lgas": _lgas()}
    pu_id = request.GET.get("pu")
    if pu_id and pu_id.isdigit():
        pu = PollingUnit.objects.filter(uniqueid=pu_id).first()
        if pu:
            rows = list(AnnouncedPuResult.objects.filter(polling_unit_uniqueid=str(pu.uniqueid)).order_by("result_id"))
            ctx.update(pu=pu, rows=rows, total=sum(r.party_score for r in rows),
                       lga=Lga.objects.filter(lga_id=pu.lga_id).first(),
                       ward=Ward.objects.filter(uniqueid=pu.uniquewardid).first(),
                       sel_lga=pu.lga_id, sel_ward=pu.uniquewardid, sel_pu=pu.uniqueid)
        else:
            ctx["error"] = "That polling unit does not exist."
    return render(request, "results/q1.html", ctx)


# ---- Question 2 ----------------------------------------------------------------
def lga_total(request):
    ctx = {"lgas": _lgas()}
    lga_id = request.GET.get("lga")
    if lga_id and lga_id.isdigit():
        lga = Lga.objects.filter(lga_id=lga_id, state_id=25).first()
        if lga:
            pu_ids = [str(i) for i in PollingUnit.objects.filter(lga_id=lga.lga_id).values_list("uniqueid", flat=True)]
            # Sum of polling-unit results only; announced_lga_results is deliberately NOT used.
            sums = (AnnouncedPuResult.objects.filter(polling_unit_uniqueid__in=pu_ids)
                    .values("party_abbreviation").annotate(total=Sum("party_score")).order_by("-total"))
            rows = list(sums)
            counted = AnnouncedPuResult.objects.filter(polling_unit_uniqueid__in=pu_ids) \
                .values("polling_unit_uniqueid").distinct().count()
            ctx.update(lga=lga, rows=rows, grand=sum(r["total"] for r in rows),
                       pu_count=len(pu_ids), pu_with_results=counted, sel_lga=lga.lga_id)
    return render(request, "results/q2.html", ctx)


# ---- Question 3 ----------------------------------------------------------------
def new_result(request):
    parties = _party_codes()
    ctx = {"lgas": _lgas(), "parties": parties, "values": {}}
    if request.method == "POST":
        p = request.POST
        errors, scores = [], {}
        ctx["values"] = p
        ward = Ward.objects.filter(uniqueid=p.get("ward") or 0).first()
        lga = Lga.objects.filter(lga_id=p.get("lga") or 0, state_id=25).first()
        name = (p.get("pu_name") or "").strip()
        entered_by = (p.get("entered_by") or "").strip()
        if not lga:
            errors.append("Choose a local government.")
        if not ward or (lga and ward.lga_id != lga.lga_id):
            errors.append("Choose a ward that belongs to the selected LGA.")
        if not name:
            errors.append("Enter the polling unit name.")
        if not entered_by:
            errors.append("Enter your name.")
        for _, code in parties:
            raw = (p.get(f"score_{code}") or "").strip()
            if not raw.isdigit():
                errors.append(f"Score for {code} must be a whole number (0 or more).")
            else:
                scores[code] = int(raw)
        if errors:
            ctx.update(errors=errors, sel_lga=p.get("lga"), sel_ward=p.get("ward"))
            return render(request, "results/q3.html", ctx)

        ip = request.META.get("REMOTE_ADDR", "")
        now = timezone.now()
        with transaction.atomic():
            last = PollingUnit.objects.filter(uniquewardid=ward.uniqueid).order_by("-polling_unit_id").first()
            next_no = (last.polling_unit_id if last else 0) + 1
            pu = PollingUnit.objects.create(
                polling_unit_id=next_no, ward_id=ward.ward_id, lga_id=lga.lga_id,
                uniquewardid=ward.uniqueid,
                polling_unit_number=(p.get("pu_number") or "").strip() or None,
                polling_unit_name=name, polling_unit_description=name,
                entered_by_user=entered_by, date_entered=now, user_ip_address=ip)
            AnnouncedPuResult.objects.bulk_create([
                AnnouncedPuResult(polling_unit_uniqueid=str(pu.uniqueid), party_abbreviation=code,
                                  party_score=scores[code], entered_by_user=entered_by,
                                  date_entered=now, user_ip_address=ip)
                for _, code in parties])
        ctx = {"saved": pu, "lga": lga, "ward": ward, "scores": scores, "lgas": _lgas(),
               "parties": parties, "values": {}}
    return render(request, "results/q3.html", ctx)

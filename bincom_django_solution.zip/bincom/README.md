# Bincom Developer Test – Delta State Election Results (Django)

| Question | URL | What it does |
|---|---|---|
| 1 | `/polling-unit/` | LGA → Ward → Polling Unit chained dropdowns, shows that unit's per-party result |
| 2 | `/lga-total/` | Pick an LGA; shows the **sum of polling-unit results** (never `announced_lga_results`) |
| 3 | `/new-result/` | Create a new polling unit and store scores for all 9 parties in `announced_pu_results` |

## Run locally (SQLite, zero setup)
```
pip install -r requirements.txt
python manage.py runserver
```
`bincom.sqlite3` is pre-built from `bincom_test.sql`. To rebuild: `python setup_sqlite.py bincom_test.sql`.

## Run against MySQL (original dump)
Import `bincom_test.sql`, `pip install mysqlclient`, then set `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`.

## Deploy (free options)
Render / Railway / PythonAnywhere: build `pip install -r requirements.txt && python manage.py collectstatic --noinput`,
start `gunicorn config.wsgi`, env vars `DEBUG=0`, `SECRET_KEY=<random>`, `ALLOWED_HOSTS=<your-domain>`,
`CSRF_TRUSTED_ORIGINS=https://<your-domain>`. Note: SQLite on Render's free tier resets on redeploy; use MySQL for persistence.

## Data notes
- Delta State = `state_id` 25. `polling_unit.lga_id` maps to `lga.lga_id`; `polling_unit.uniquewardid` maps to `ward.uniqueid` (`ward.ward_id` is NOT unique).
- `announced_pu_results.polling_unit_uniqueid` is a varchar that stores `polling_unit.uniqueid`.
- 170 polling units in the dump have `lga_id = 0` and no ward, so they cannot appear in the dropdowns.
- `party_abbreviation` is CHAR(4), so LABOUR is stored as `LABO`.
